package com.synex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelgigApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelgigApplication.class, args);
	}

}
