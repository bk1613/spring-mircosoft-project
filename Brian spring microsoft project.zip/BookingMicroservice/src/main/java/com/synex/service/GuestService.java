package com.synex.service;

import com.synex.domain.Guest;

public interface GuestService {
	public Guest save(Guest gt);
}
